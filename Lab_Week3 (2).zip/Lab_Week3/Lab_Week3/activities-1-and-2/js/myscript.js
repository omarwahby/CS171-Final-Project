var amusementRides = [
    {
        "id" : 1,
        "name": "Space Mountain",
        "price_in_usd": 400,
        "opening_days": ["Monday", "Wednesday"],
        "children": true
    },
    {
        "id" : 2,
        "name": "Soaring through California",
        "price_in_usd": 300,
        "opening_days": ["Thursday", "Friday"],
        "children": true
    },
    {
        "id" : 3,
        "name": "Indiana Jones Adventure",
        "price_in_usd": 400,
        "opening_days": ["Saturday", "Sunday"],
        "children": true
    }
]

console.log("Name of First Amusement Ride: " + amusementRides[0].name);

console.log("Days when the second attraction is open: " + amusementRides[1].opening_days)

console.log("First opening day from the second amusement ride: " + amusementRides[1].opening_days[0])

let discounted_price = amusementRides[2].price_in_usd * 0.5
console.log("Discounted price of third attraction: " + discounted_price)

// Calling the function
let amusementRidesDouble = doublePrices(amusementRides);
console.log(amusementRidesDouble);

// Implementation of the function
function doublePrices(amusementRides) {

    // TODO: Modify data here ...
    amusementRides.forEach( (element, index) => {
        // Skip over second element
        if (index != 1) {
            element.price_in_usd *= 2
        }
    });

    return amusementRides;
}

// Calling the function
debugAmusementRides(amusementRides);

// Implementation of the function
function debugAmusementRides(amusementRides) {
    // Declare variable to hold info to be displayed on console
    let amusement_rides_displayed = "";
    amusementRides.forEach( (element, index) => {

        amusement_rides_displayed += "Name of attraction: " + element.name + ", New Price: " + element.price_in_usd + "<br/>";
        console.log("Name of attraction: " + element.name + ", New Price: " + element.price_in_usd)
    });

    document.getElementById("attractions").innerHTML = amusement_rides_displayed;
}



